<!DOCTYPE html>
<html>
<head>
    <title>Personel Filtreleme</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Personel Filtreleme</h2>
        <form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="form-group">
                <label for="gorev_yeri">Görev Yeri:</label>
                <select class="form-control" id="gorev_yeri" name="gorev_yeri">
                    <option value="">Tümü</option>
                    <?php
                    $gorev_yerleri = array('Büro', 'Sarnıç', 'Tümbüldek', 'Suuçtu', 'Sanayi', 'Sırmalar', 'Orta', 'Otopark', 'Ges');
                    foreach ($gorev_yerleri as $yer) {
                        $selected = (isset($_GET["gorev_yeri"]) && $_GET["gorev_yeri"] == $yer) ? "selected" : "";
                        echo "<option value='$yer' $selected>$yer</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Filtrele</button>
        </form>

        <div class="mt-3">
            <?php
            $servername = "localhost"; // Sunucu adı
            $username = "muratozsay_personel"; // Veritabanı kullanıcı adı
            $password = "muratozsay_personel"; // Veritabanı parolası
            $dbname = "muratozsay_personel"; // Veritabanı adı

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }

            // Veritabanını seç
            $conn->select_db($dbname);

            $sql = "SELECT * FROM personel";
            if (isset($_GET["gorev_yeri"]) && $_GET["gorev_yeri"] != "") {
                $gorev_yeri = $_GET["gorev_yeri"];
                $sql .= " WHERE gorev_yeri = '$gorev_yeri'";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<table class="table table-striped">
                        <tr>
                            <th>ID</th>
                            <th>Ad</th>
                            <th>Sicil No</th>
                            <th>Görev</th>
                            <th>Görev Yeri</th>
                            <th>Kalan İzin</th>
                            <th>Kullanılan İzin</th>
                            <th>Kan Grubu</th>
                            <th>Telefon</th>
                            <th>Adres</th>
                        </tr>';
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>".$row["id"]."</td>
                            <td>".$row["ad"]."</td>
                            <td>".$row["sicil_no"]."</td>
                            <td>".$row["gorev"]."</td>
                            <td>".$row["gorev_yeri"]."</td>
                            <td>".$row["kalan_izin"]."</td>
                            <td>".$row["kullanilan_izin"]."</td>
                            <td>".$row["kan_grubu"]."</td>
                            <td>".$row["telefon"]."</td>
                            <td>".$row["adres"]."</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "Kayıt bulunamadı.";
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
