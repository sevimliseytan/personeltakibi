<!DOCTYPE html>
<html>
<head>
    <title>Personel Ekle</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Personel Ekle</h2>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="form-group">
                <label for="ad">Ad:</label>
                <input type="text" class="form-control" id="ad" name="ad" required>
            </div>
            <div class="form-group">
                <label for="sicil_no">Sicil No:</label>
                <input type="text" class="form-control" id="sicil_no" name="sicil_no" required>
            </div>
            <div class="form-group">
                <label for="gorev">Görev:</label>
                <input type="text" class="form-control" id="gorev" name="gorev" required>
            </div>
            <div class="form-group">
                <label for="gorev_yeri">Görev Yeri:</label>
                <select class="form-control" id="gorev_yeri" name="gorev_yeri">
                    <option value="Büro">Büro</option>
                    <option value="Sarnıç">Sarnıç</option>
                    <option value="Tümbüldek">Tümbüldek</option>
                    <option value="Suuçtu">Suuçtu</option>
                    <option value="Sanayi">Sanayi</option>
                    <option value="Sırmalar">Sırmalar</option>
                    <option value="Orta">Orta</option>
                    <option value="Otopark">Otopark</option>
                    <option value="Ges">Ges</option>
                </select>
            </div>
            <div class="form-group">
                <label for="kalan_izin">Kalan İzin:</label>
                <input type="number" class="form-control" id="kalan_izin" name="kalan_izin" required>
            </div>
            <div class="form-group">
                <label for="kullanilan_izin">Kullanılan İzin:</label>
                <input type="number" class="form-control" id="kullanilan_izin" name="kullanilan_izin" required>
            </div>
            <div class="form-group">
                <label for="kan_grubu">Kan Grubu:</label>
                <input type="text" class="form-control" id="kan_grubu" name="kan_grubu">
            </div>
            <div class="form-group">
                <label for="telefon">Telefon:</label>
                <input type="text" class="form-control" id="telefon" name="telefon">
            </div>
            <div class="form-group">
                <label for="adres">Adres:</label>
                <textarea class="form-control" id="adres" name="adres"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Kaydet</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $servername = "localhost"; // Sunucu adı
            $username = "muratozsay_personel"; // Veritabanı kullanıcı adı
            $password = "muratozsay_personel"; // Veritabanı parolası
            $dbname = "muratozsay_personel"; // Veritabanı adı

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }

            $ad = $_POST["ad"];
            $sicil_no = $_POST["sicil_no"];
            $gorev = $_POST["gorev"];
            $gorev_yeri = $_POST["gorev_yeri"];
            $kalan_izin = $_POST["kalan_izin"];
            $kullanilan_izin = $_POST["kullanilan_izin"];
            $kan_grubu = $_POST["kan_grubu"];
            $telefon = $_POST["telefon"];
            $adres = $_POST["adres"];

            $sql = "INSERT INTO personel (ad, sicil_no, gorev, gorev_yeri, kalan_izin, kullanilan_izin, kan_grubu, telefon, adres) 
                    VALUES ('$ad', '$sicil_no', '$gorev', '$gorev_yeri', $kalan_izin, $kullanilan_izin, '$kan_grubu', '$telefon', '$adres')";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success mt-3'>Personel başarıyla eklendi.</div>";
            } else {
                echo "<div class='alert alert-danger mt-3'>Hata: " . $sql . "<br>" . $conn->error . "</div>";
            }

            $conn->close();
        }
        ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
