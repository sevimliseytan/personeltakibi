<!DOCTYPE html>
<html>
<head>
    <title>Personel Düzenle</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Personel Düzenle</h2>

        <?php
        $servername = "localhost"; // Sunucu adı
        $username = "muratozsay_personel"; // Veritabanı kullanıcı adı
        $password = "muratozsay_personel"; // Veritabanı parolası
        $dbname = "muratozsay_personel"; // Veritabanı adı

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Bağlantı hatası: " . $conn->connect_error);
        }

        // Veritabanını seç
        $conn->select_db($dbname);

        if (isset($_GET["id"])) {
            $personel_id = $_GET["id"];

            $sql = "SELECT * FROM personel WHERE id = $personel_id";
            $result = $conn->query($sql);

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                ?>
                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
                    <div class="form-group">
                        <label for="ad">Ad:</label>
                        <input type="text" class="form-control" id="ad" name="ad" value="<?php echo $row["ad"]; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="sicil_no">Sicil No:</label>
                        <input type="text" class="form-control" id="sicil_no" name="sicil_no" value="<?php echo $row["sicil_no"]; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="gorev">Görev:</label>
                        <input type="text" class="form-control" id="gorev" name="gorev" value="<?php echo $row["gorev"]; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="gorev_yeri">Görev Yeri:</label>
                        <select class="form-control" id="gorev_yeri" name="gorev_yeri">
                            <?php
                            $gorev_yerleri = array('Büro', 'Sarnıç', 'Tümbüldek', 'Suuçtu', 'Sanayi', 'Sırmalar', 'Orta', 'Otopark', 'Ges');
                            foreach ($gorev_yerleri as $yer) {
                                $selected = ($yer == $row["gorev_yeri"]) ? "selected" : "";
                                echo "<option value='$yer' $selected>$yer</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="kalan_izin">Kalan İzin:</label>
                        <input type="number" class="form-control" id="kalan_izin" name="kalan_izin" value="<?php echo $row["kalan_izin"]; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="kullanilan_izin">Kullanılan İzin:</label>
                        <input type="number" class="form-control" id="kullanilan_izin" name="kullanilan_izin" value="<?php echo $row["kullanilan_izin"]; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="kan_grubu">Kan Grubu:</label>
                        <input type="text" class="form-control" id="kan_grubu" name="kan_grubu" value="<?php echo $row["kan_grubu"]; ?>">
                    </div>
                    <div class="form-group">
                        <label for="telefon">Telefon:</label>
                        <input type="text" class="form-control" id="telefon" name="telefon" value="<?php echo $row["telefon"]; ?>">
                    </div>
                    <div class="form-group">
                        <label for="adres">Adres:</label>
                        <textarea class="form-control" id="adres" name="adres"><?php echo $row["adres"]; ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Güncelle</button>
                </form>
                <?php
            } else {
                echo "Personel bulunamadı.";
            }
        } else {
            echo "Geçersiz personel ID'si.";
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id = $_POST["id"];
            $ad = $_POST["ad"];
            $sicil_no = $_POST["sicil_no"];
            $gorev = $_POST["gorev"];
            $gorev_yeri = $_POST["gorev_yeri"];
            $kalan_izin = $_POST["kalan_izin"];
            $kullanilan_izin = $_POST["kullanilan_izin"];
            $kan_grubu = $_POST["kan_grubu"];
            $telefon = $_POST["telefon"];
            $adres = $_POST["adres"];

            $sql = "UPDATE personel SET ad='$ad', sicil_no='$sicil_no', gorev='$gorev', gorev_yeri='$gorev_yeri', kalan_izin=$kalan_izin, kullanilan_izin=$kullanilan_izin, kan_grubu='$kan_grubu', telefon='$telefon', adres='$adres' WHERE id=$id";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success mt-3'>Personel başarıyla güncellendi.</div>";
            } else {
                echo "<div class='alert alert-danger mt-3'>Hata: " . $sql . "<br>" . $conn->error . "</div>";
            }
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
