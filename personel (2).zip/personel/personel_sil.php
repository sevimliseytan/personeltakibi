<?php
if (isset($_GET["id"])) {
    $personel_id = $_GET["id"];

    $servername = "localhost"; // Sunucu adı
    $username = "muratozsay_personel"; // Veritabanı kullanıcı adı
    $password = "muratozsay_personel"; // Veritabanı parolası
    $dbname = "muratozsay_personel"; // Veritabanı adı

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $sql = "DELETE FROM personel WHERE id = $personel_id";

    if ($conn->query($sql) === TRUE) {
        echo "Personel başarıyla silindi.";
        header("Location: index.php"); // Silme işleminden sonra index.php'ye yönlendir
        exit();
    } else {
        echo "Hata: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    echo "Geçersiz personel ID'si.";
}
?>
