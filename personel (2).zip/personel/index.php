<!DOCTYPE html>
<html>
<head>
    <title>Personel ve İzin Takibi</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" href="#">Personel</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">İzin</a>
            </li>
        </ul>

        <div class="tab-content mt-3">
            <div class="tab-pane active" id="personel">
                <h2>Personel Listesi</h2>
                <a href="personel_ekle.php" class="btn btn-success mb-3">Personel Ekle</a>

                <?php
                // Veritabanı bağlantısı
                $servername = "localhost"; // Sunucu adı
                $username = "muratozsay_personel"; // Veritabanı kullanıcı adı
                $password = "muratozsay_personel"; // Veritabanı parolası
                $dbname = "muratozsay_personel"; // Veritabanı adı

                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Bağlantı hatası: " . $conn->connect_error);
                }

                // Personel verilerini çekme
                $sql = "SELECT * FROM personel";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo '<table class="table table-striped">
                            <tr>
                                <th>ID</th>
                                <th>Ad</th>
                                <th>Sicil No</th>
                                <th>Görev</th>
                                <th>Görev Yeri</th>
                                <th>Kalan İzin</th>
                                <th>Kullanılan İzin</th>
                                <th>Kan Grubu</th>
                                <th>Telefon</th>
                                <th>Adres</th>
                                <th>İşlemler</th>
                            </tr>';
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>".$row["id"]."</td>
                                <td>".$row["ad"]."</td>
                                <td>".$row["sicil_no"]."</td>
                                <td>".$row["gorev"]."</td>
                                <td>".$row["gorev_yeri"]."</td>
                                <td>".$row["kalan_izin"]."</td>
                                <td>".$row["kullanilan_izin"]."</td>
                                <td>".$row["kan_grubu"]."</td>
                                <td>".$row["telefon"]."</td>
                                <td>".$row["adres"]."</td>
                                <td>
                                    <a href='personel_duzenle.php?id=".$row["id"]."' class='btn btn-primary btn-sm'>Düzenle</a>
                                    <a href='personel_sil.php?id=".$row["id"]."' class='btn btn-danger btn-sm' onclick='return confirm(\"Silmek istediğinize emin misiniz?\");'>Sil</a>
                                </td>
                              </tr>";
                    }
                    echo "</table>";
                } else {
                    echo "Kayıt bulunamadı.";
                }
                $conn->close();
                ?>
            </div>

            <div class="tab-pane" id="izin">
                <h2>İzin Takibi</h2>
                </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
